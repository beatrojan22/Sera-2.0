# Restaurant QR Ordering System

Customers scan a table QR code → browse menu → place order (no payment) → kitchen cooks → waiter is alerted with the table number → customer can re-order or tap **Get bill** → waiter prints the bill and collects cash.

Runs on **Windows** (server + any browser) and on **phones/tablets** (any browser, optional "Add to Home screen").

## Quick start (Windows)
1. Install Node.js LTS from https://nodejs.org
2. Double-click **start.bat** (first run installs packages).
3. The console prints the addresses. Open `http://localhost:3000/admin` on the PC.
   - Admin PIN `0000`, staff PIN `1234` — change both in Admin → Settings.
4. Admin → QR codes → **Print all QR codes**, stick one on each table.
5. On the kitchen device open `http://<PC-IP>:3000/kitchen`; on each waiter phone open `http://<PC-IP>:3000/waiter`.

All devices must be on the same Wi-Fi as the PC. If phones cannot connect, allow Node.js through Windows Firewall (private networks), or run once in an admin PowerShell:
`netsh advfirewall firewall add rule name="Restaurant" dir=in action=allow protocol=TCP localport=3000`

## Screens
| URL | Who | What |
|---|---|---|
| `/t/<n>` | Customer | Menu, cart, orders, live status, Get bill |
| `/kitchen` | Kitchen | New / Preparing / Ready columns, sound alert, "EDITED" flag |
| `/waiter` | Waiter | Ready-to-serve alerts, pending orders (edit/cancel), payments (print bill, mark paid), table map (place orders for guests) |
| `/admin` | Owner | Menu CRUD + stock toggle, QR codes, settings, today's sales |

## Notes
- Data lives in `data/data.json` (back it up; delete it to reset to the sample menu).
- Orders can be edited/cancelled by the waiter only while still new or being cooked.
- Printing uses the browser print dialog (formatted for 80 mm receipt printers; any printer works).
- To use over the internet (customers on mobile data), host this on a server/VPS with HTTPS, or use a tunnel such as Cloudflare Tunnel, and put that public address in Admin → Settings → Public address, then reprint QR codes.
- Change the port with `set PORT=8080` before `node server.js`.
