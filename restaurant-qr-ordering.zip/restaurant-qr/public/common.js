const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let CUR = '';
const money = n => CUR + Number(n).toFixed(Number(n) % 1 ? 2 : 0);
const timeStr = t => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
const ago = t => { const m = Math.floor((Date.now() - t) / 60000); return m < 1 ? 'just now' : m + ' min'; };

async function api(method, url, body) {
  const res = await fetch(url, {
    method, headers: { 'Content-Type': 'application/json', 'x-token': localStorage.getItem('token') || '' },
    body: body ? JSON.stringify(body) : undefined
  });
  if (res.status === 401) { showLogin(); throw new Error('Login required'); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Something went wrong');
  return data;
}

/* toasts + sound */
function toast(msg, kind = '', ms = 4500) {
  let box = $('.toasts');
  if (!box) { box = document.createElement('div'); box.className = 'toasts'; box.setAttribute('aria-live', 'polite'); document.body.appendChild(box); }
  const t = document.createElement('div'); t.className = 'toast ' + kind; t.textContent = msg; box.appendChild(t);
  setTimeout(() => t.remove(), ms);
}
let actx;
const AC = window.AudioContext || window.webkitAudioContext;
document.addEventListener('click', () => { try { actx = actx || new AC(); actx.resume(); } catch (e) {} });
function beep(n = 2) {
  try {
    actx = actx || new AC();
    for (let i = 0; i < n; i++) {
      const o = actx.createOscillator(), g = actx.createGain();
      o.type = 'sine'; o.frequency.value = 880; g.gain.value = .18;
      o.connect(g); g.connect(actx.destination);
      const t = actx.currentTime + i * .28; o.start(t); o.stop(t + .16);
    }
  } catch (e) {}
  if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
}

/* live connection */
function connectWS(handler) {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  const open = () => {
    const ws = new WebSocket(`${proto}://${location.host}/ws`);
    ws.onopen = () => { const d = $('#conn'); if (d) d.classList.add('on'); handler({ type: 'connected' }); };
    ws.onmessage = e => { try { handler(JSON.parse(e.data)); } catch (x) {} };
    ws.onclose = () => { const d = $('#conn'); if (d) d.classList.remove('on'); setTimeout(open, 2000); };
  };
  open();
}

/* staff login */
let NEED = 'staff', INIT = null;
function showLogin() {
  let el = $('#login');
  if (!el) {
    el = document.createElement('div'); el.id = 'login'; el.className = 'login';
    el.innerHTML = `<div class="card"><h2 id="lt"></h2><p class="mute">Enter the PIN to continue.</p>
      <input id="pin" type="password" inputmode="numeric" autocomplete="current-password" placeholder="PIN">
      <div class="err" id="lerr"></div><button class="btn block" id="lgo">Sign in</button></div>`;
    document.body.appendChild(el);
    $('#lgo').onclick = doLogin;
    $('#pin').onkeydown = e => { if (e.key === 'Enter') doLogin(); };
  }
  $('#lt').textContent = NEED === 'admin' ? 'Admin sign in' : 'Staff sign in';
  $('#lerr').textContent = ''; $('#pin').value = ''; el.hidden = false; setTimeout(() => $('#pin').focus(), 50);
}
async function doLogin() {
  const r = await fetch('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pin: $('#pin').value, role: NEED }) });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) { $('#lerr').textContent = d.error || 'Could not sign in'; return; }
  localStorage.setItem('token', d.token); $('#login').hidden = true; runInit();
}
async function runInit() { try { await INIT(); } catch (e) { if (e.message !== 'Login required') toast(e.message, 'hot'); } }
function startStaff(role, init) {
  NEED = role; INIT = init;
  if (localStorage.getItem('token')) runInit(); else showLogin();
}
function logout() { localStorage.removeItem('token'); location.reload(); }

/* printing */
function printEl(id, cls) {
  const done = () => { document.body.classList.remove(cls); window.removeEventListener('afterprint', done); };
  document.body.classList.add(cls); window.addEventListener('afterprint', done);
  setTimeout(done, 30000);
  setTimeout(() => window.print(), 80);
}
async function printBill(table) {
  const b = await api('GET', '/api/staff/bill/' + table);
  let el = $('#receipt');
  if (!el) { el = document.createElement('div'); el.id = 'receipt'; document.body.appendChild(el); }
  const c = b.currency;
  const f = n => c + Number(n).toFixed(2);
  el.innerHTML = `<h2>${esc(b.restaurant)}</h2><div class="c">Table ${b.table}<br>${new Date(b.date).toLocaleString()}</div><hr>
    <table>${b.lines.map(l => `<tr><td>${l.qty} x ${esc(l.name)}</td><td>${f(l.price * l.qty)}</td></tr>`).join('')}</table><hr>
    <table><tr><td>Subtotal</td><td>${f(b.subtotal)}</td></tr><tr><td>Tax (${b.taxPercent}%)</td><td>${f(b.tax)}</td></tr>
    <tr><td><b>TOTAL</b></td><td><b>${f(b.total)}</b></td></tr></table><hr><div class="c">Thank you! Please visit again.</div>`;
  printEl('receipt', 'print-receipt');
}
