// Restaurant QR Ordering - server
const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');
const QRCode = require('qrcode');

const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data', 'data.json');

/* ---------- storage ---------- */
function seed() {
  const m = (id, name, category, price, emoji, description) => ({ id, name, category, price, emoji, description, available: true });
  return {
    settings: {
      name: 'My Restaurant', currency: '₹', taxPercent: 5, tables: 10, baseUrl: '',
      staffPin: '1234', adminPin: '0000', secret: crypto.randomBytes(16).toString('hex')
    },
    menu: [
      m(1, 'Paneer Tikka', 'Starters', 240, '🧀', 'Charred cottage cheese with mint chutney'),
      m(2, 'Veg Spring Rolls', 'Starters', 180, '🥟', 'Crisp rolls, sweet chilli dip'),
      m(3, 'Tomato Soup', 'Starters', 120, '🍅', 'Slow-cooked, finished with cream'),
      m(4, 'Butter Paneer Masala', 'Mains', 290, '🍛', 'Rich tomato-butter gravy'),
      m(5, 'Dal Tadka', 'Mains', 210, '🥣', 'Yellow lentils, cumin and garlic tadka'),
      m(6, 'Veg Biryani', 'Mains', 260, '🍚', 'Fragrant basmati with raita'),
      m(7, 'Butter Naan', 'Breads', 50, '🫓', 'Tandoor-baked, brushed with butter'),
      m(8, 'Tandoori Roti', 'Breads', 30, '🫓', 'Whole wheat, straight from the tandoor'),
      m(9, 'Masala Chai', 'Drinks', 40, '☕', 'Ginger and cardamom'),
      m(10, 'Fresh Lime Soda', 'Drinks', 70, '🍋', 'Sweet, salted or mixed'),
      m(11, 'Sweet Lassi', 'Drinks', 90, '🥛', 'Thick, chilled yoghurt drink'),
      m(12, 'Gulab Jamun', 'Desserts', 110, '🍮', 'Two warm dumplings in rose syrup')
    ],
    orders: [], billRequests: {}, payments: [], seq: { order: 0, menu: 12, payment: 0 }
  };
}
let db;
function save() {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DATA_FILE);
}
function load() {
  try { db = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); }
  catch (e) { db = seed(); save(); }
  const cutoff = Date.now() - 30 * 864e5; // tidy: drop paid orders older than 30 days
  db.orders = db.orders.filter(o => !(o.paid && o.paidAt < cutoff));
  db.payments = db.payments.slice(-3000);
}
load();

/* ---------- helpers ---------- */
const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });
function broadcast(m) {
  const s = JSON.stringify(m);
  wss.clients.forEach(c => c.readyState === 1 && c.send(s));
}
function lanIP() {
  const list = [];
  Object.values(os.networkInterfaces()).forEach(a => (a || []).forEach(i => {
    if (i.family === 'IPv4' && !i.internal) list.push(i.address);
  }));
  return list.find(a => /^(192\.168|10\.|172\.(1[6-9]|2\d|3[01]))/.test(a)) || list[0] || 'localhost';
}
const baseUrl = () => (db.settings.baseUrl || `http://${lanIP()}:${PORT}`).replace(/\/+$/, '');
const str = (v, max = 80) => String(v == null ? '' : v).trim().slice(0, max);

const sign = role => crypto.createHmac('sha256', db.settings.secret)
  .update(role + ':' + (role === 'admin' ? db.settings.adminPin : db.settings.staffPin)).digest('hex');
const makeToken = role => role + '.' + sign(role);
function roleOf(req) {
  const t = String(req.headers['x-token'] || req.query.token || '');
  const [role, sig] = t.split('.');
  if ((role === 'staff' || role === 'admin') && sig && sig === sign(role)) return role;
  return null;
}
const auth = need => (req, res, next) => {
  const r = roleOf(req);
  if (!r || (need === 'admin' && r !== 'admin')) return res.status(401).json({ error: 'Login required' });
  next();
};

const activeOrders = t => db.orders.filter(o => !o.paid && (t == null || o.table === t));
const live = orders => orders.filter(o => o.status !== 'cancelled');
function totals(orders) {
  const sub = live(orders).reduce((s, o) => s + o.items.reduce((a, i) => a + i.price * i.qty, 0), 0);
  const tax = Math.round(sub * db.settings.taxPercent) / 100;
  return { subtotal: Math.round(sub * 100) / 100, tax, total: Math.round((sub + tax) * 100) / 100 };
}
const validTable = v => { const n = parseInt(v, 10); return n >= 1 && n <= db.settings.tables ? n : null; };
const publicOrder = o => ({ id: o.id, status: o.status, items: o.items, note: o.note, createdAt: o.createdAt });

function placeOrder(table, body, source) {
  const items = [];
  if (!Array.isArray(body.items) || !body.items.length || body.items.length > 50) return { error: 'Your cart is empty' };
  for (const r of body.items) {
    const qty = parseInt(r.qty, 10);
    const m = db.menu.find(x => x.id === Number(r.id));
    if (!m) return { error: 'An item is no longer on the menu' };
    if (!m.available) return { error: `${m.name} is sold out` };
    if (!(qty >= 1 && qty <= 20)) return { error: 'Quantity must be between 1 and 20' };
    const ex = items.find(i => i.id === m.id);
    if (ex) ex.qty += qty; else items.push({ id: m.id, name: m.name, price: m.price, qty });
  }
  if (activeOrders(table).filter(o => o.status === 'new').length >= 8) return { error: 'The kitchen has several orders from this table already. Please wait a moment.' };
  const o = { id: ++db.seq.order, table, items, note: str(body.note, 200), status: 'new', source, edited: false, paid: false, createdAt: Date.now(), updatedAt: Date.now() };
  db.orders.push(o); save();
  broadcast({ type: 'new_order', table, id: o.id });
  return { order: o };
}
function billFor(table) {
  const orders = live(activeOrders(table));
  const map = new Map();
  orders.forEach(o => o.items.forEach(i => {
    const k = i.name + '|' + i.price;
    const e = map.get(k) || { name: i.name, price: i.price, qty: 0 };
    e.qty += i.qty; map.set(k, e);
  }));
  return { restaurant: db.settings.name, currency: db.settings.currency, taxPercent: db.settings.taxPercent, table, date: Date.now(), lines: [...map.values()], ...totals(orders) };
}

/* ---------- middleware & pages ---------- */
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));
const page = f => (req, res) => res.sendFile(path.join(__dirname, 'public', f));
app.get('/t/:table', page('customer.html'));
['kitchen', 'waiter', 'admin'].forEach(p => app.get('/' + p, page(p + '.html')));

/* ---------- public API (customers) ---------- */
app.get('/api/menu', (req, res) => {
  const { name, currency, taxPercent, tables } = db.settings;
  res.json({ settings: { name, currency, taxPercent, tables }, menu: db.menu });
});
app.get('/api/table/:table', (req, res) => {
  const t = validTable(req.params.table);
  if (!t) return res.status(404).json({ error: 'Unknown table' });
  const orders = activeOrders(t);
  res.json({ table: t, orders: orders.map(publicOrder), billRequested: !!db.billRequests[t], ...totals(orders) });
});
app.post('/api/table/:table/order', (req, res) => {
  const t = validTable(req.params.table);
  if (!t) return res.status(404).json({ error: 'Unknown table' });
  const r = placeOrder(t, req.body, 'customer');
  if (r.error) return res.status(400).json({ error: r.error });
  res.json(publicOrder(r.order));
});
app.post('/api/table/:table/bill', (req, res) => {
  const t = validTable(req.params.table);
  if (!t) return res.status(404).json({ error: 'Unknown table' });
  if (!live(activeOrders(t)).length) return res.status(400).json({ error: 'Place an order first' });
  if (!db.billRequests[t]) { db.billRequests[t] = Date.now(); save(); broadcast({ type: 'bill_request', table: t }); }
  res.json({ ok: true });
});

/* ---------- login ---------- */
const fails = new Map();
app.post('/api/login', (req, res) => {
  const f = fails.get(req.ip) || { n: 0, t: Date.now() };
  if (Date.now() - f.t > 300000) { f.n = 0; f.t = Date.now(); }
  if (f.n >= 10) return res.status(429).json({ error: 'Too many attempts. Try again in a few minutes.' });
  const role = req.body.role === 'admin' ? 'admin' : 'staff';
  const pin = String(req.body.pin || '');
  const real = String(role === 'admin' ? db.settings.adminPin : db.settings.staffPin);
  if (pin !== real) { f.n++; fails.set(req.ip, f); return res.status(401).json({ error: 'Wrong PIN' }); }
  res.json({ token: makeToken(role), role });
});

/* ---------- staff API (kitchen + waiter) ---------- */
app.get('/api/staff/orders', auth('staff'), (req, res) => res.json(live(activeOrders()).sort((a, b) => a.createdAt - b.createdAt)));

app.get('/api/staff/tables', auth('staff'), (req, res) => {
  const out = [];
  for (let t = 1; t <= db.settings.tables; t++) {
    const o = live(activeOrders(t));
    out.push({ table: t, orders: o.length, ready: o.filter(x => x.status === 'ready').length, billRequested: db.billRequests[t] || null, ...totals(o) });
  }
  res.json(out);
});

app.post('/api/staff/orders/:id/status', auth('staff'), (req, res) => {
  const o = db.orders.find(x => x.id == req.params.id && !x.paid);
  const s = req.body.status;
  if (!o) return res.status(404).json({ error: 'Order not found' });
  if (!['new', 'preparing', 'ready', 'served', 'cancelled'].includes(s)) return res.status(400).json({ error: 'Bad status' });
  o.status = s; o.updatedAt = Date.now(); save();
  broadcast({ type: s === 'ready' ? 'order_ready' : s === 'cancelled' ? 'order_cancelled' : 'order_status', table: o.table, id: o.id, status: s });
  res.json(o);
});

app.put('/api/staff/orders/:id', auth('staff'), (req, res) => {
  const o = db.orders.find(x => x.id == req.params.id && !x.paid);
  if (!o) return res.status(404).json({ error: 'Order not found' });
  if (!['new', 'preparing'].includes(o.status)) return res.status(400).json({ error: 'This order is already prepared and can no longer be edited' });
  if (!Array.isArray(req.body.items)) return res.status(400).json({ error: 'Items missing' });
  const items = JSON.parse(JSON.stringify(o.items));
  for (const r of req.body.items) {
    const id = Number(r.id), qty = parseInt(r.qty, 10);
    if (!(qty >= 0 && qty <= 20)) return res.status(400).json({ error: 'Quantity must be between 0 and 20' });
    const ex = items.find(i => i.id === id);
    if (ex) ex.qty = qty;
    else if (qty > 0) {
      const m = db.menu.find(x => x.id === id);
      if (!m || !m.available) return res.status(400).json({ error: 'Item not available' });
      items.push({ id, name: m.name, price: m.price, qty });
    }
  }
  o.items = items.filter(i => i.qty > 0);
  if (!o.items.length) o.status = 'cancelled';
  o.edited = true; o.updatedAt = Date.now(); save();
  broadcast({ type: o.status === 'cancelled' ? 'order_cancelled' : 'order_edited', table: o.table, id: o.id });
  res.json(o);
});

app.post('/api/staff/table/:table/order', auth('staff'), (req, res) => {
  const t = validTable(req.params.table);
  if (!t) return res.status(404).json({ error: 'Unknown table' });
  const r = placeOrder(t, req.body, 'waiter');
  if (r.error) return res.status(400).json({ error: r.error });
  res.json(r.order);
});

app.get('/api/staff/bill/:table', auth('staff'), (req, res) => {
  const t = validTable(req.params.table);
  if (!t) return res.status(404).json({ error: 'Unknown table' });
  res.json(billFor(t));
});

app.post('/api/staff/table/:table/pay', auth('staff'), (req, res) => {
  const t = validTable(req.params.table);
  if (!t) return res.status(404).json({ error: 'Unknown table' });
  const b = billFor(t);
  if (!b.lines.length) return res.status(400).json({ error: 'Nothing to pay on this table' });
  const now = Date.now();
  db.payments.push({ id: ++db.seq.payment, table: t, subtotal: b.subtotal, tax: b.tax, total: b.total, at: now, method: 'cash', items: b.lines.map(l => ({ name: l.name, qty: l.qty, price: l.price })) });
  activeOrders(t).forEach(o => { o.paid = true; o.paidAt = now; });
  delete db.billRequests[t]; save();
  broadcast({ type: 'paid', table: t });
  res.json({ ok: true, total: b.total });
});

/* ---------- admin API ---------- */
app.get('/api/admin/info', auth('admin'), (req, res) => res.json({ baseUrl: baseUrl(), settings: { ...db.settings, secret: undefined } }));

function menuFields(b, cur = {}) {
  const price = Number(b.price);
  if (!str(b.name) || !(price >= 0)) return null;
  return {
    name: str(b.name), category: str(b.category, 40) || 'Other', price: Math.round(price * 100) / 100,
    emoji: str(b.emoji, 4) || '🍽️', description: str(b.description, 140),
    available: b.available === undefined ? (cur.available !== false) : !!b.available
  };
}
app.post('/api/admin/menu', auth('admin'), (req, res) => {
  const f = menuFields(req.body);
  if (!f) return res.status(400).json({ error: 'Name and a valid price are required' });
  const item = { id: ++db.seq.menu, ...f };
  db.menu.push(item); save(); broadcast({ type: 'menu' }); res.json(item);
});
app.put('/api/admin/menu/:id', auth('admin'), (req, res) => {
  const m = db.menu.find(x => x.id == req.params.id);
  if (!m) return res.status(404).json({ error: 'Item not found' });
  const f = menuFields(req.body, m);
  if (!f) return res.status(400).json({ error: 'Name and a valid price are required' });
  Object.assign(m, f); save(); broadcast({ type: 'menu' }); res.json(m);
});
app.delete('/api/admin/menu/:id', auth('admin'), (req, res) => {
  db.menu = db.menu.filter(x => x.id != req.params.id); save(); broadcast({ type: 'menu' }); res.json({ ok: true });
});
app.put('/api/admin/settings', auth('admin'), (req, res) => {
  const b = req.body, s = db.settings;
  const tables = parseInt(b.tables, 10), tax = Number(b.taxPercent);
  if (!(tables >= 1 && tables <= 200)) return res.status(400).json({ error: 'Tables must be 1 to 200' });
  if (!(tax >= 0 && tax <= 100)) return res.status(400).json({ error: 'Tax must be 0 to 100' });
  if (str(b.staffPin, 20).length < 4 || str(b.adminPin, 20).length < 4) return res.status(400).json({ error: 'PINs need at least 4 characters' });
  Object.assign(s, { name: str(b.name) || s.name, currency: str(b.currency, 4) || s.currency, taxPercent: tax, tables,
    baseUrl: str(b.baseUrl, 200), staffPin: str(b.staffPin, 20), adminPin: str(b.adminPin, 20) });
  save(); broadcast({ type: 'menu' });
  res.json({ ok: true, token: makeToken('admin') });
});
app.get('/api/admin/qr/:table', auth('admin'), async (req, res) => {
  const t = validTable(req.params.table);
  if (!t) return res.status(404).end();
  const png = await QRCode.toBuffer(`${baseUrl()}/t/${t}`, { width: 600, margin: 2, errorCorrectionLevel: 'M' });
  res.type('png').send(png);
});
app.get('/api/admin/report', auth('admin'), (req, res) => {
  const start = new Date(); start.setHours(0, 0, 0, 0);
  const today = db.payments.filter(p => p.at >= start.getTime());
  const top = new Map();
  today.forEach(p => p.items.forEach(i => top.set(i.name, (top.get(i.name) || 0) + i.qty)));
  const total = today.reduce((s, p) => s + p.total, 0);
  res.json({
    bills: today.length, total: Math.round(total * 100) / 100,
    average: today.length ? Math.round(total / today.length * 100) / 100 : 0,
    top: [...top.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([name, qty]) => ({ name, qty })),
    recent: db.payments.slice(-10).reverse().map(p => ({ table: p.table, total: p.total, at: p.at }))
  });
});

app.use((err, req, res, next) => res.status(400).json({ error: 'Bad request' }));

server.listen(PORT, '0.0.0.0', () => {
  const ip = lanIP();
  console.log('\n  Restaurant system is running\n');
  console.log(`  This PC:        http://localhost:${PORT}`);
  console.log(`  Phones/tablets: http://${ip}:${PORT}   (same Wi-Fi)`);
  console.log(`  Kitchen screen: http://${ip}:${PORT}/kitchen`);
  console.log(`  Waiter screen:  http://${ip}:${PORT}/waiter`);
  console.log(`  Admin / QR:     http://${ip}:${PORT}/admin`);
  console.log('\n  Default PINs: staff 1234, admin 0000 (change them in Admin > Settings)\n');
});
