@echo off
cd /d %~dp0
where node >nul 2>nul || (echo Node.js is not installed. Install the LTS version from https://nodejs.org and run this file again. & pause & exit /b)
if not exist node_modules (echo Installing, please wait... & call npm install)
echo Starting restaurant system...
node server.js
pause
